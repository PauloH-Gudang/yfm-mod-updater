#ifndef MEMORIES_DECOMP_FUNC_8003A198_H
#define MEMORIES_DECOMP_FUNC_8003A198_H

#include "../types.h"

/* Walks three levels of halfword offset tables rooted at `b`: entry `x` of the
 * root gives the offset of a second table, entry `y` of that gives a third,
 * and entry `z` of the third must be non-zero. Returns 1 when all three are
 * non-zero, 0 at the first zero. DisplayEffect_BuildResourceObjects asks it
 * about the table at D_801AF000 or D_801AF800. */
int DisplayEffect_HasResourceEntry(
    unsigned char *base, int group, int row, int entry);

#endif
